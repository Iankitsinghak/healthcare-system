
import React from 'react';

function Patients() {
  return <div className="container"><h1>Patient List</h1></div>;
}

export default Patients;
