
import React from 'react';

function Home() {
  return <div className="container"><h1>Healthcare Home</h1></div>;
}

export default Home;
